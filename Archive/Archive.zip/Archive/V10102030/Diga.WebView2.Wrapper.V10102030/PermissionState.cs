﻿namespace Diga.WebView2.Wrapper
{
    public enum PermissionState
    {
        Default,
        Allow,
        Deny,
    }
}
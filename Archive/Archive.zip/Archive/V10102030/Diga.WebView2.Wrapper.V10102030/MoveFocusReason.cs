﻿namespace Diga.WebView2.Wrapper
{
    public enum MoveFocusReason
    {
        Programatic,
        Next,
        Previous,
    }
}
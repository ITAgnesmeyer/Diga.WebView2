﻿namespace Diga.WebView2.Wrapper
{
    public enum ScriptDialogKind
    {
        Alert,
        Confirm,
        Prompt,
        BeforeUnload
    }
}
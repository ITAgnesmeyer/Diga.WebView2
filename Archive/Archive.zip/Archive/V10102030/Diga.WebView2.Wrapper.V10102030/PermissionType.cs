﻿namespace Diga.WebView2.Wrapper
{
    public enum PermissionType
    {
        UnknownPermission,
        Microphone,
        Camera,
        Geolocation,
        Notifications,
        OtherSensors,
        ClipboardRead,
    }
}
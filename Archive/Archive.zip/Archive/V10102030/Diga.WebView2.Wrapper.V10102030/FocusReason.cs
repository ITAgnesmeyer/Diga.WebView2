﻿namespace Diga.WebView2.Wrapper
{
    public enum FocusReason
    {
        Programatic,
        Next,
        Previous,
    }
}
﻿namespace Diga.WebView2.Wrapper
{
    public enum ImageFormat
    {
        Png,
        Jpeg
    }
}
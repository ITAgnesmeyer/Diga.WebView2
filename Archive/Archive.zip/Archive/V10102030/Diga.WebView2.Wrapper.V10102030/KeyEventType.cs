﻿namespace Diga.WebView2.Wrapper
{
    public enum KeyEventType
    {
        KeyDown,
        KeyUp,
        SystemKeyDown,
        SystemKeyUp,
    }
}
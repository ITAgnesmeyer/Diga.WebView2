﻿// Decompiled with JetBrains decompiler
// Type: Diga.WebView2.Interop.COREWEBVIEW2_MOVE_FOCUS_REASON
// Assembly: Diga.WebView2.Interop, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 1E8B0323-528E-4C9C-8FF8-A486637C87E1
// Assembly location: O:\webview2\V1096133\Diga.WebView2.Interop.dll

namespace Diga.WebView2.Interop
{
  public enum COREWEBVIEW2_MOVE_FOCUS_REASON
  {
    COREWEBVIEW2_MOVE_FOCUS_REASON_PROGRAMMATIC,
    COREWEBVIEW2_MOVE_FOCUS_REASON_NEXT,
    COREWEBVIEW2_MOVE_FOCUS_REASON_PREVIOUS,
  }
}

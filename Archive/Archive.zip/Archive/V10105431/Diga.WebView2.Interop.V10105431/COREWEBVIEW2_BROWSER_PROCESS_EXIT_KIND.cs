﻿// Decompiled with JetBrains decompiler
// Type: Diga.WebView2.Interop.COREWEBVIEW2_BROWSER_PROCESS_EXIT_KIND
// Assembly: Diga.WebView2.Interop, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 78A35386-8488-46E1-BA73-85C815D94A35
// Assembly location: O:\webview2\V1099228\Diga.WebView2.Interop.dll

namespace Diga.WebView2.Interop
{
  public enum COREWEBVIEW2_BROWSER_PROCESS_EXIT_KIND
  {
    COREWEBVIEW2_BROWSER_PROCESS_EXIT_KIND_NORMAL,
    COREWEBVIEW2_BROWSER_PROCESS_EXIT_KIND_FAILED,
  }
}
